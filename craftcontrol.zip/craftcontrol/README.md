# ⛏ CraftControl — Minecraft Dashboard

A local web dashboard that connects to your real Minecraft Java installation.

## Features
- 🌍 **Worlds** — reads all your saves, shows game mode, day count, seed, size, last played
- ✦ **Mods** — lists every .jar in your mods folder, toggle enable/disable in one click
- 🗺 **World Map** — interactive procedural biome map, drag & pinch-zoom, shows seed
- ⚙ **Settings** — reads & writes your real `options.txt` (render distance, FPS, FOV, audio, etc.)
- 📦 **Installations** — shows all your launcher profiles with version & loader info
- 🎨 **Resource Packs** & 📷 **Screenshots** browser
- 📱 **Mobile-friendly** — full bottom nav, pinch-zoom on the map, responsive layout

## Setup

### Requirements
- **Node.js 16+** — https://nodejs.org
- **Minecraft Java Edition** installed

### Install & Run

```bash
# 1. Extract this folder anywhere
# 2. Install dependencies (one time only)
cd craftcontrol
npm install

# 3. Start the server + open browser
node start.js

# OR just the server (then open http://localhost:3000 manually)
node server.js
```

The dashboard automatically finds your `.minecraft` folder:
- **macOS**: `~/Library/Application Support/minecraft`
- **Windows**: `%APPDATA%\.minecraft`
- **Linux**: `~/.minecraft`

## What it reads
| File | Used for |
|------|----------|
| `launcher_profiles.json` | Installations tab, profile selector |
| `saves/*/level.dat` | World name, game mode, seed, day count |
| `saves/*/icon.png` | World thumbnail |
| `[gameDir]/mods/*.jar` | Mod Manager |
| `[gameDir]/options.txt` | Settings (read + write) |
| `resourcepacks/` | Resource Packs tab |
| `screenshots/` | Screenshots tab |

## Toggling Mods
Clicking a mod toggle renames the file between `modname.jar` ↔ `modname.jar.disabled`.
This is the standard way Fabric/Forge launchers disable mods. **Restart Minecraft** after changes.

## Saving Settings
The Settings tab reads your real `options.txt` and writes changes back when you hit **Save**.
**Restart Minecraft** to apply — the game reads options.txt on launch.

## Troubleshooting
- **"Cannot connect to server"** — make sure `node server.js` is running in a terminal
- **No worlds showing** — check your saves folder exists at the path shown in the terminal
- **No mods** — switch the profile selector to the installation that has your mods folder
- **Port 3000 in use** — change `const PORT = 3000` in `server.js` to e.g. `3001`
