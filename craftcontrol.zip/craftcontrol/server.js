/**
 * CraftControl Server v2 — Windows-first, full feature set
 * - Proper Windows path detection (%APPDATA%\.minecraft)
 * - prismarine-nbt for accurate level.dat parsing
 * - Player stats (deaths, playtime, advancements)
 * - Real chunk region reading for biome map
 * - Modrinth mod search + download
 * - World backup & restore
 */

const express  = require('express');
const cors     = require('cors');
const fs       = require('fs');
const path     = require('path');
const os       = require('os');
const zlib     = require('zlib');
const nbt      = require('prismarine-nbt');

const app  = express();
const PORT = 3000;
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── Minecraft directory (Windows-first) ─────────────────────────────────────
function getMinecraftDir() {
  const platform = os.platform();
  const home     = os.homedir();
  if (platform === 'win32') {
    const appdata = process.env.APPDATA;
    if (appdata) return path.join(appdata, '.minecraft');
    return path.join(home, 'AppData', 'Roaming', '.minecraft');
  }
  if (platform === 'darwin')
    return path.join(home, 'Library', 'Application Support', 'minecraft');
  return path.join(home, '.minecraft');
}

const MC_DIR = getMinecraftDir();
console.log('Minecraft dir:', MC_DIR);
console.log('Exists:', fs.existsSync(MC_DIR));

// ─── Helpers ──────────────────────────────────────────────────────────────────
function safeReadJSON(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; }
}
function safeReadDir(p) {
  try { return fs.readdirSync(p); } catch { return []; }
}
function formatBytes(b) {
  if (!b || b < 1024) return (b||0) + ' B';
  if (b < 1048576)    return (b/1024).toFixed(1) + ' KB';
  if (b < 1073741824) return (b/1048576).toFixed(1) + ' MB';
  return (b/1073741824).toFixed(2) + ' GB';
}
function getDirSize(dir, depth=0) {
  if (depth > 5) return 0;
  let total = 0;
  try {
    for (const e of fs.readdirSync(dir)) {
      try {
        const s = fs.statSync(path.join(dir, e));
        total += s.isDirectory() ? getDirSize(path.join(dir, e), depth+1) : s.size;
      } catch {}
    }
  } catch {}
  return total;
}
function copyDirSync(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src)) {
    const s = path.join(src, entry), d = path.join(dest, entry);
    const stat = fs.statSync(s);
    if (stat.isDirectory()) copyDirSync(s, d);
    else fs.copyFileSync(s, d);
  }
}

// ─── NBT: parse level.dat ─────────────────────────────────────────────────────
async function parseLevelDat(levelDatPath) {
  try {
    const buf = fs.readFileSync(levelDatPath);
    const { parsed } = await nbt.parse(buf);
    const data = nbt.simplify(parsed);
    const D = data.Data || data;

    const gameModes   = ['Survival','Creative','Adventure','Spectator'];
    const difficulties = ['Peaceful','Easy','Normal','Hard'];

    // DayTime can be a BigInt-like object from the NBT lib
    const toNum = v => {
      if (v == null) return 0;
      if (typeof v === 'object' && v.valueOf) return Number(v.valueOf());
      return Number(v);
    };

    const dayTime = toNum(D.DayTime);

    // Seed: try new format first (WorldGenSettings.seed), then legacy RandomSeed
    let seed = null;
    if (D.WorldGenSettings?.seed != null) seed = String(toNum(D.WorldGenSettings.seed));
    else if (D.RandomSeed != null) seed = String(toNum(D.RandomSeed));

    // LastPlayed in ms
    let lastPlayed = null;
    const lp = toNum(D.LastPlayed);
    if (lp > 0) lastPlayed = new Date(lp).toISOString();

    return {
      worldName:  D.LevelName   || null,
      gameMode:   gameModes[D.GameType    ?? 0] || 'Survival',
      difficulty: difficulties[D.Difficulty ?? 2] || 'Normal',
      hardcore:   D.hardcore     === 1 || D.hardcore === true,
      cheats:     D.allowCommands === 1 || D.allowCommands === true,
      mcDay:      Math.floor(dayTime / 24000),
      dayTime,
      seed,
      version:    D.Version?.Name || null,
      spawnX:     D.SpawnX || 0,
      spawnY:     D.SpawnY || 64,
      spawnZ:     D.SpawnZ || 0,
      lastPlayed,
    };
  } catch (e) {
    console.error('level.dat parse error:', levelDatPath, e.message);
    return null;
  }
}

// ─── Player stats ─────────────────────────────────────────────────────────────
function parsePlayerStats(worldPath) {
  try {
    const statsDir = path.join(worldPath, 'stats');
    if (!fs.existsSync(statsDir)) return null;
    const files = fs.readdirSync(statsDir).filter(f => f.endsWith('.json'));
    if (!files.length) return null;

    // Most recently modified stats file
    const statsFile = files
      .map(f => ({ f, mt: fs.statSync(path.join(statsDir, f)).mtimeMs }))
      .sort((a,b) => b.mt - a.mt)[0].f;

    const raw = JSON.parse(fs.readFileSync(path.join(statsDir, statsFile), 'utf8'));
    const s   = raw.stats || raw;

    const custom   = s['minecraft:custom']   || {};
    const killed   = s['minecraft:killed']   || {};
    const killedBy = s['minecraft:killed_by'] || {};
    const mined    = s['minecraft:mined']    || {};
    const crafted  = s['minecraft:crafted']  || {};
    const used     = s['minecraft:used']     || {};

    const ticks    = custom['minecraft:play_time'] || custom['minecraft:play_one_minute'] || 0;

    const topMined = Object.entries(mined)
      .sort(([,a],[,b]) => b-a).slice(0,8)
      .map(([k,v]) => ({ block: k.replace('minecraft:',''), count: v }));

    const topKilled = Object.entries(killed)
      .sort(([,a],[,b]) => b-a).slice(0,5)
      .map(([k,v]) => ({ mob: k.replace('minecraft:',''), count: v }));

    const topKilledBy = Object.entries(killedBy)
      .sort(([,a],[,b]) => b-a).slice(0,5)
      .map(([k,v]) => ({ mob: k.replace('minecraft:',''), count: v }));

    return {
      uuid:         statsFile.replace('.json',''),
      hoursPlayed:  parseFloat((ticks / 72000).toFixed(1)),
      deaths:       custom['minecraft:deaths']         || 0,
      walkKm:       parseFloat(((custom['minecraft:walk_one_cm']||0)/100000).toFixed(1)),
      swimKm:       parseFloat(((custom['minecraft:swim_one_cm']||0)/100000).toFixed(1)),
      flyKm:        parseFloat(((custom['minecraft:fly_one_cm'] ||0)/100000).toFixed(1)),
      jumps:        custom['minecraft:jump']           || 0,
      dmgDealt:     Math.round((custom['minecraft:damage_dealt']||0)/10),
      dmgTaken:     Math.round((custom['minecraft:damage_taken']||0)/10),
      mobsKilled:   Object.values(killed).reduce((a,b)=>a+b,0),
      itemsCrafted: Object.values(crafted).reduce((a,b)=>a+b,0),
      chestsOpened: used['minecraft:chest'] || 0,
      itemsDropped: Object.values(s['minecraft:dropped']||{}).reduce((a,b)=>a+b,0),
      sleepCount:   custom['minecraft:sleep_in_bed']   || 0,
      tradeCount:   custom['minecraft:traded_with_villager'] || 0,
      topMined, topKilled, topKilledBy,
    };
  } catch (e) {
    console.error('Stats error:', e.message);
    return null;
  }
}

// ─── Advancements ─────────────────────────────────────────────────────────────
function parseAdvancements(worldPath) {
  try {
    const advDir = path.join(worldPath, 'advancements');
    if (!fs.existsSync(advDir)) return null;
    const files = fs.readdirSync(advDir).filter(f => f.endsWith('.json'));
    if (!files.length) return null;

    const advFile = files
      .map(f => ({ f, mt: fs.statSync(path.join(advDir, f)).mtimeMs }))
      .sort((a,b) => b.mt - a.mt)[0].f;

    const raw = JSON.parse(fs.readFileSync(path.join(advDir, advFile), 'utf8'));
    let total = 0, done = 0;
    const categories = { story:0, nether:0, end:0, adventure:0, husbandry:0 };

    for (const [key, val] of Object.entries(raw)) {
      if (key === 'DataVersion') continue;
      if (!key.includes(':')) continue;
      total++;
      if (val.done === true) {
        done++;
        const cat = key.split('/')[0].split(':').pop();
        if (cat in categories) categories[cat]++;
      }
    }
    return { total, done, percent: total ? Math.round(done/total*100) : 0, categories };
  } catch { return null; }
}

// ─── Biome colour maps ────────────────────────────────────────────────────────
// Modern (1.18+) uses string palette like "minecraft:forest"
const BIOME_COLORS_MODERN = {
  'minecraft:ocean':                    '#1565C0',
  'minecraft:deep_ocean':               '#0D47A1',
  'minecraft:cold_ocean':               '#1A237E',
  'minecraft:deep_cold_ocean':          '#0D1B5E',
  'minecraft:frozen_ocean':             '#4FC3F7',
  'minecraft:deep_frozen_ocean':        '#29B6F6',
  'minecraft:lukewarm_ocean':           '#039BE5',
  'minecraft:deep_lukewarm_ocean':      '#0277BD',
  'minecraft:warm_ocean':               '#0288D1',
  'minecraft:deep_warm_ocean':          '#01579B',
  'minecraft:river':                    '#3949AB',
  'minecraft:frozen_river':             '#90CAF9',
  'minecraft:beach':                    '#F9A825',
  'minecraft:snowy_beach':              '#F5F5F5',
  'minecraft:stony_shore':              '#9E9E9E',
  'minecraft:plains':                   '#8BC34A',
  'minecraft:sunflower_plains':         '#CDDC39',
  'minecraft:meadow':                   '#66BB6A',
  'minecraft:forest':                   '#2E7D32',
  'minecraft:flower_forest':            '#43A047',
  'minecraft:birch_forest':             '#558B2F',
  'minecraft:old_growth_birch_forest':  '#558B2F',
  'minecraft:dark_forest':              '#1B5E20',
  'minecraft:old_growth_pine_taiga':    '#4E342E',
  'minecraft:old_growth_spruce_taiga':  '#5D4037',
  'minecraft:taiga':                    '#00695C',
  'minecraft:snowy_taiga':              '#4DB6AC',
  'minecraft:snowy_plains':             '#E3F2FD',
  'minecraft:ice_spikes':               '#B3E5FC',
  'minecraft:snowy_slopes':             '#CFD8DC',
  'minecraft:grove':                    '#78909C',
  'minecraft:frozen_peaks':             '#ECEFF1',
  'minecraft:jagged_peaks':             '#B0BEC5',
  'minecraft:stony_peaks':              '#795548',
  'minecraft:desert':                   '#F57F17',
  'minecraft:badlands':                 '#BF360C',
  'minecraft:eroded_badlands':          '#E64A19',
  'minecraft:wooded_badlands':          '#8D6E63',
  'minecraft:jungle':                   '#1B5E20',
  'minecraft:sparse_jungle':            '#33691E',
  'minecraft:bamboo_jungle':            '#2E7D32',
  'minecraft:savanna':                  '#F9A825',
  'minecraft:savanna_plateau':          '#F57F17',
  'minecraft:windswept_savanna':        '#FFCA28',
  'minecraft:windswept_hills':          '#607D8B',
  'minecraft:windswept_gravelly_hills': '#78909C',
  'minecraft:windswept_forest':         '#546E7A',
  'minecraft:swamp':                    '#004D40',
  'minecraft:mangrove_swamp':           '#00695C',
  'minecraft:mushroom_fields':          '#880E4F',
  'minecraft:dripstone_caves':          '#6D4C41',
  'minecraft:lush_caves':               '#388E3C',
  'minecraft:deep_dark':                '#212121',
  'minecraft:cherry_grove':             '#F48FB1',
  'minecraft:pale_garden':              '#ECEFF1',
  // Nether
  'minecraft:nether_wastes':            '#B71C1C',
  'minecraft:soul_sand_valley':         '#4E342E',
  'minecraft:crimson_forest':           '#C62828',
  'minecraft:warped_forest':            '#00695C',
  'minecraft:basalt_deltas':            '#37474F',
  // End
  'minecraft:the_end':                  '#4A148C',
  'minecraft:small_end_islands':        '#4A148C',
  'minecraft:end_midlands':             '#827717',
  'minecraft:end_highlands':            '#F9A825',
  'minecraft:end_barrens':              '#311B92',
  'minecraft:the_void':                 '#000000',
};

// Legacy numeric IDs (pre-1.18)
const BIOME_COLORS_LEGACY = {
  0:'#1565C0', 1:'#8BC34A', 2:'#F57F17', 3:'#607D8B', 4:'#2E7D32',
  5:'#00695C', 6:'#004D40', 7:'#3949AB', 8:'#B71C1C', 9:'#4A148C',
  10:'#4FC3F7',11:'#90CAF9',12:'#E3F2FD',13:'#CFD8DC',14:'#880E4F',
  15:'#880E4F',16:'#F9A825',17:'#F57F17',18:'#2E7D32',19:'#00695C',
  20:'#607D8B',21:'#1B5E20',22:'#1B5E20',23:'#33691E',24:'#0D47A1',
  25:'#9E9E9E',26:'#F5F5F5',27:'#558B2F',28:'#558B2F',29:'#1B5E20',
  30:'#4DB6AC',31:'#4DB6AC',32:'#4E342E',33:'#4E342E',34:'#546E7A',
  35:'#F9A825',36:'#F57F17',37:'#BF360C',38:'#8D6E63',39:'#BF360C',
  44:'#039BE5',45:'#039BE5',46:'#1565C0',47:'#0277BD',48:'#0277BD',
  49:'#1A237E',50:'#29B6F6',
  // Mutated/rare variants
  129:'#CDDC39',130:'#FFCA28',131:'#795548',132:'#2E7D32',133:'#43A047',
  134:'#00695C',140:'#B3E5FC',149:'#1B5E20',151:'#33691E',155:'#558B2F',
  156:'#558B2F',157:'#1B5E20',158:'#4DB6AC',161:'#5D4037',162:'#4E342E',
  163:'#FFCA28',164:'#F57F17',165:'#880E4F',166:'#6D4C41',167:'#4E342E',
};

function getBiomeColor(biomeName) {
  if (typeof biomeName === 'string') {
    return BIOME_COLORS_MODERN[biomeName]
      || BIOME_COLORS_MODERN['minecraft:' + biomeName]
      || '#8BC34A';
  }
  if (typeof biomeName === 'number') {
    return BIOME_COLORS_LEGACY[biomeName] || '#8BC34A';
  }
  return '#8BC34A';
}

// ─── Structure icons & display names ─────────────────────────────────────────
const STRUCTURE_META = {
  'minecraft:village':           { icon:'🏘', label:'Village',           color:'#FFD700' },
  'minecraft:village_plains':    { icon:'🏘', label:'Plains Village',    color:'#FFD700' },
  'minecraft:village_desert':    { icon:'🏜', label:'Desert Village',    color:'#FF8C00' },
  'minecraft:village_savanna':   { icon:'🌿', label:'Savanna Village',   color:'#90EE90' },
  'minecraft:village_snowy':     { icon:'❄️', label:'Snowy Village',     color:'#87CEEB' },
  'minecraft:village_taiga':     { icon:'🌲', label:'Taiga Village',     color:'#228B22' },
  'minecraft:stronghold':        { icon:'🏰', label:'Stronghold',        color:'#C0C0C0' },
  'minecraft:mineshaft':         { icon:'⛏',  label:'Mineshaft',         color:'#8B4513' },
  'minecraft:mineshaft_mesa':    { icon:'⛏',  label:'Mesa Mineshaft',    color:'#D2691E' },
  'minecraft:monument':          { icon:'🏛', label:'Ocean Monument',    color:'#00CED1' },
  'minecraft:ocean_monument':    { icon:'🏛', label:'Ocean Monument',    color:'#00CED1' },
  'minecraft:woodland_mansion':  { icon:'🏚', label:'Woodland Mansion',  color:'#8B0000' },
  'minecraft:mansion':           { icon:'🏚', label:'Woodland Mansion',  color:'#8B0000' },
  'minecraft:desert_pyramid':    { icon:'🔺', label:'Desert Temple',     color:'#FF8C00' },
  'minecraft:igloo':             { icon:'🏔', label:'Igloo',             color:'#F0FFFF' },
  'minecraft:jungle_pyramid':    { icon:'🛕', label:'Jungle Temple',     color:'#228B22' },
  'minecraft:swamp_hut':         { icon:'🧙', label:'Witch Hut',         color:'#4B0082' },
  'minecraft:shipwreck':         { icon:'⚓', label:'Shipwreck',         color:'#8B4513' },
  'minecraft:shipwreck_beached': { icon:'⚓', label:'Shipwreck',         color:'#8B4513' },
  'minecraft:buried_treasure':   { icon:'💰', label:'Buried Treasure',   color:'#FFD700' },
  'minecraft:ocean_ruin':        { icon:'🌊', label:'Ocean Ruins',       color:'#4682B4' },
  'minecraft:ocean_ruin_cold':   { icon:'🌊', label:'Ocean Ruins',       color:'#4682B4' },
  'minecraft:ocean_ruin_warm':   { icon:'🌊', label:'Ocean Ruins',       color:'#4682B4' },
  'minecraft:pillager_outpost':  { icon:'🗼', label:'Pillager Outpost',  color:'#808080' },
  'minecraft:outpost':           { icon:'🗼', label:'Pillager Outpost',  color:'#808080' },
  'minecraft:ruined_portal':     { icon:'🟣', label:'Ruined Portal',     color:'#8A2BE2' },
  'minecraft:ruined_portal_desert': { icon:'🟣', label:'Ruined Portal', color:'#8A2BE2' },
  'minecraft:ruined_portal_jungle': { icon:'🟣', label:'Ruined Portal', color:'#8A2BE2' },
  'minecraft:ruined_portal_mountain': { icon:'🟣', label:'Ruined Portal', color:'#8A2BE2' },
  'minecraft:ruined_portal_nether': { icon:'🔴', label:'Ruined Portal (Nether)', color:'#FF4500' },
  'minecraft:ruined_portal_ocean': { icon:'🟣', label:'Ruined Portal', color:'#8A2BE2' },
  'minecraft:ruined_portal_swamp': { icon:'🟣', label:'Ruined Portal', color:'#8A2BE2' },
  'minecraft:bastion_remnant':   { icon:'🏯', label:'Bastion Remnant',  color:'#B22222' },
  'minecraft:nether_fortress':   { icon:'🌋', label:'Nether Fortress',  color:'#FF4500' },
  'minecraft:nether_fossil':     { icon:'🦴', label:'Nether Fossil',    color:'#D2691E' },
  'minecraft:end_city':          { icon:'🌌', label:'End City',         color:'#9370DB' },
  'minecraft:fortress':          { icon:'🌋', label:'Nether Fortress',  color:'#FF4500' },
  'minecraft:ancient_city':      { icon:'🏟', label:'Ancient City',     color:'#2F4F4F' },
  'minecraft:trail_ruins':       { icon:'🏺', label:'Trail Ruins',      color:'#8B7355' },
  'minecraft:trial_chambers':    { icon:'⚗️', label:'Trial Chambers',   color:'#708090' },
};

function getStructureMeta(key) {
  return STRUCTURE_META[key]
    || STRUCTURE_META['minecraft:' + key]
    || { icon:'📍', label: key.replace('minecraft:','').replace(/_/g,' '), color:'#FF69B4' };
}

// ─── Region file helpers ──────────────────────────────────────────────────────
function getWorldRegions(worldPath, dimension) {
  const dimMap = {
    overworld: path.join(worldPath, 'region'),
    nether:    path.join(worldPath, 'DIM-1', 'region'),
    end:       path.join(worldPath, 'DIM1',  'region'),
  };
  const regionDir = dimMap[dimension] || dimMap.overworld;
  if (!fs.existsSync(regionDir)) return [];
  return safeReadDir(regionDir)
    .filter(f => f.endsWith('.mca'))
    .map(f => {
      const m = f.match(/r\.(-?\d+)\.(-?\d+)\.mca/);
      return m ? { file: path.join(regionDir, f), rx: parseInt(m[1]), rz: parseInt(m[2]) } : null;
    }).filter(Boolean);
}

// Decompress one chunk from a region buffer
function decompressChunk(regionBuf, localX, localZ) {
  const i = localX + localZ * 32;
  const offset  = ((regionBuf[i*4] << 16) | (regionBuf[i*4+1] << 8) | regionBuf[i*4+2]) * 4096;
  const sectors = regionBuf[i*4+3];
  if (offset < 8192 || sectors === 0) return null;
  if (offset + 5 > regionBuf.length) return null;
  const len  = regionBuf.readUInt32BE(offset);
  if (len < 1 || offset + 4 + len > regionBuf.length) return null;
  const compression = regionBuf[offset + 4];
  const compressed  = regionBuf.slice(offset + 5, offset + 4 + len);
  try {
    if (compression === 2) return zlib.inflateSync(compressed);
    if (compression === 1) return zlib.gunzipSync(compressed);
    if (compression === 3) return compressed; // uncompressed
  } catch { return null; }
  return null;
}

// Parse biome from a chunk's NBT data — handles 1.18+ palette and legacy int array
function extractChunkBiome(chunkData) {
  try {
    // 1.18+ format: sections[].biomes.palette (array of strings)
    const sections = chunkData.sections || chunkData.Sections;
    if (Array.isArray(sections)) {
      // Find a non-empty section near y=64 (surface) — sections are 16 blocks tall
      // y=64 is in section index 4 (sections go from y=-64 in 1.18+, index 0 = y -64...-49)
      // Try section indices 4-8 (y=0 to y=80) for surface biome
      const preferredIdx = [4, 5, 3, 6, 2, 7, 1, 8, 0];
      for (const idx of preferredIdx) {
        const sec = sections[idx];
        if (!sec) continue;
        const biomes = sec.biomes || sec.Biomes;
        if (!biomes) continue;
        const palette = biomes.palette || biomes.Palette;
        if (Array.isArray(palette) && palette.length > 0) {
          // Return the most common biome in the palette (first is usually dominant)
          return palette[0];
        }
      }
      // fallback: any section with a biome
      for (const sec of sections) {
        if (!sec) continue;
        const biomes = sec.biomes || sec.Biomes;
        if (!biomes) continue;
        const palette = biomes.palette || biomes.Palette;
        if (Array.isArray(palette) && palette.length > 0) return palette[0];
      }
    }

    // Legacy format (pre-1.18): Level.Biomes is an int array of 256 values (16x16)
    const level = chunkData.Level || chunkData;
    const biomeArr = level.Biomes || level.biomes;
    if (biomeArr) {
      const arr = Array.isArray(biomeArr) ? biomeArr : Object.values(biomeArr);
      if (arr.length > 0) {
        // Count most common biome
        const counts = {};
        for (const b of arr) {
          if (b !== undefined && b !== null && b !== -1) {
            counts[b] = (counts[b] || 0) + 1;
          }
        }
        const dominant = Object.entries(counts).sort((a,b) => b[1]-a[1])[0];
        if (dominant) return parseInt(dominant[0]);
      }
    }
  } catch {}
  return null;
}

// Extract structures from a chunk's NBT — works for 1.18+ and legacy
function extractChunkStructures(chunkData, worldChunkX, worldChunkZ) {
  const found = [];
  try {
    const root     = chunkData;
    const level    = chunkData.Level || chunkData;
    const structs  = root.structures || level.Structures || level.structures;
    if (!structs) return found;

    // 1.18+: structures.starts is a map of structure_type -> {Children, BB, id, ...}
    const starts = structs.starts || structs.Starts;
    if (starts && typeof starts === 'object') {
      for (const [key, val] of Object.entries(starts)) {
        if (!val || val.id === 'INVALID' || val.id === 'NONE') continue;
        // Get bounding box centre
        let bx = worldChunkX * 16 + 8;
        let bz = worldChunkZ * 16 + 8;
        const bb = val.BB || val.ChunkX; // BB = [x1,y1,z1,x2,y2,z2]
        if (Array.isArray(bb) && bb.length >= 6) {
          bx = Math.round((bb[0] + bb[3]) / 2);
          bz = Math.round((bb[2] + bb[5]) / 2);
        } else if (typeof val.ChunkX === 'number') {
          bx = val.ChunkX * 16 + 8;
          bz = (val.ChunkZ || worldChunkZ) * 16 + 8;
        }
        const structKey = key.toLowerCase().includes(':') ? key : 'minecraft:' + key.toLowerCase();
        found.push({ type: structKey, x: bx, z: bz });
      }
    }

    // References: structures.References maps type -> long array of packed chunk coords
    // Each long packs two 32-bit ints: (chunkX << 32) | chunkZ
    // We only include refs where this chunk IS the start chunk
    const refs = structs.References || structs.references;
    if (refs && typeof refs === 'object' && found.length === 0) {
      for (const [key, val] of Object.entries(refs)) {
        const arr = Array.isArray(val) ? val : [];
        for (const packed of arr) {
          // packed is a BigInt or regular number
          const p = typeof packed === 'bigint' ? packed : BigInt(Math.round(Number(packed)));
          const cx = Number(p >> 32n);
          const cz = Number(p & 0xFFFFFFFFn);
          if (cx === worldChunkX && cz === worldChunkZ) {
            const structKey = key.toLowerCase().includes(':') ? key : 'minecraft:' + key.toLowerCase();
            found.push({ type: structKey, x: cx * 16 + 8, z: cz * 16 + 8 });
          }
        }
      }
    }
  } catch {}
  return found;
}

// Read an entire region file: returns { chunks, structures }
// chunks: [{cx, cz, biome, color}]
// structures: [{type, x, z, icon, label, color}]
async function readRegionFull(regionPath, regionRx, regionRz) {
  const chunks     = [];
  const structures = [];
  const structSeen = new Set(); // deduplicate

  let regionBuf;
  try { regionBuf = fs.readFileSync(regionPath); }
  catch { return { chunks, structures }; }

  if (regionBuf.length < 8192) return { chunks, structures };

  for (let lx = 0; lx < 32; lx++) {
    for (let lz = 0; lz < 32; lz++) {
      const chunkBuf = decompressChunk(regionBuf, lx, lz);
      if (!chunkBuf) continue;

      const worldCx = regionRx * 32 + lx;
      const worldCz = regionRz * 32 + lz;

      let chunkData = null;
      try {
        const { parsed } = await nbt.parse(chunkBuf);
        chunkData = nbt.simplify(parsed);
      } catch { 
        // chunk exists but couldn't parse — mark as explored with default color
        chunks.push({ cx: lx, cz: lz, biome: null, color: '#8BC34A' });
        continue;
      }

      // Biome
      const biomeRaw = extractChunkBiome(chunkData);
      const color    = getBiomeColor(biomeRaw);
      chunks.push({ cx: lx, cz: lz, biome: typeof biomeRaw === 'string' ? biomeRaw.replace('minecraft:','') : biomeRaw, color });

      // Structures
      const found = extractChunkStructures(chunkData, worldCx, worldCz);
      for (const s of found) {
        const dedupeKey = `${s.type}:${Math.round(s.x/16)}:${Math.round(s.z/16)}`;
        if (structSeen.has(dedupeKey)) continue;
        structSeen.add(dedupeKey);
        const meta = getStructureMeta(s.type);
        structures.push({ ...s, ...meta });
      }
    }
  }
  return { chunks, structures };
}

// ─── API routes ───────────────────────────────────────────────────────────────

app.get('/api/status', (req, res) => {
  res.json({
    mcDir: MC_DIR,
    found: fs.existsSync(MC_DIR),
    platform: os.platform(),
    saves: fs.existsSync(path.join(MC_DIR, 'saves')),
    mods: fs.existsSync(path.join(MC_DIR, 'mods')),
    profiles: fs.existsSync(path.join(MC_DIR, 'launcher_profiles.json')),
  });
});

app.get('/api/installations', (req, res) => {
  const profilesPath = path.join(MC_DIR, 'launcher_profiles.json');
  const data = safeReadJSON(profilesPath);
  if (!data) return res.json({ profiles: [], error: 'launcher_profiles.json not found at ' + profilesPath, mcDir: MC_DIR });

  const profiles = Object.entries(data.profiles || {}).map(([id, p]) => {
    const versionId = p.lastVersionId || p.version || 'unknown';
    const vid = versionId.toLowerCase();
    let loader = 'Vanilla';
    if (vid.includes('fabric'))    loader = 'Fabric';
    else if (vid.includes('neoforge')) loader = 'NeoForge';
    else if (vid.includes('forge')) loader = 'Forge';
    else if (vid.includes('quilt')) loader = 'Quilt';
    else if (vid.includes('optifine')) loader = 'OptiFine';

    const baseMatch = versionId.match(/(\d+\.\d+(?:\.\d+)?)/);
    const baseVersion = baseMatch ? baseMatch[1] : versionId;

    // Resolve gameDir — handle %APPDATA% and ~ on Windows
    let gameDir = MC_DIR;
    if (p.gameDir && p.gameDir.trim()) {
      gameDir = p.gameDir
        .replace(/%APPDATA%/gi, process.env.APPDATA || '')
        .replace(/%USERPROFILE%/gi, os.homedir())
        .replace(/^~/, os.homedir());
    }

    const modsDir = path.join(gameDir, 'mods');
    const modCount = fs.existsSync(modsDir)
      ? safeReadDir(modsDir).filter(f => f.endsWith('.jar') || f.endsWith('.jar.disabled')).length
      : 0;

    let ramGb = null;
    if (p.javaArgs) {
      const m = p.javaArgs.match(/-Xmx(\d+)([gGmM])/);
      if (m) ramGb = m[2].toLowerCase() === 'm' ? (parseInt(m[1])/1024).toFixed(1)+' GB' : m[1]+' GB';
    }

    return {
      id, name: p.name || versionId,
      versionId, baseVersion, loader,
      gameDir, modsDir, modCount, hasMods: modCount > 0,
      javaArgs: p.javaArgs || '', ramGb,
      created: p.created || null, lastUsed: p.lastUsed || null,
      type: p.type || 'custom',
    };
  }).sort((a, b) => {
    if (a.lastUsed && b.lastUsed) return new Date(b.lastUsed) - new Date(a.lastUsed);
    return a.lastUsed ? -1 : b.lastUsed ? 1 : 0;
  });

  res.json({ profiles, mcDir: MC_DIR });
});

app.get('/api/worlds', async (req, res) => {
  const savesDir = path.join(MC_DIR, 'saves');
  if (!fs.existsSync(savesDir)) return res.json({ worlds: [], savesDir, error: 'saves folder not found at ' + savesDir });

  const worlds = [];
  for (const entry of safeReadDir(savesDir)) {
    const worldPath = path.join(savesDir, entry);
    try {
      if (!fs.statSync(worldPath).isDirectory()) continue;
      const levelDatPath = path.join(worldPath, 'level.dat');
      if (!fs.existsSync(levelDatPath)) continue;

      const nbtData = await parseLevelDat(levelDatPath);

      let iconBase64 = null;
      const iconPath = path.join(worldPath, 'icon.png');
      if (fs.existsSync(iconPath)) {
        try { iconBase64 = 'data:image/png;base64,' + fs.readFileSync(iconPath).toString('base64'); } catch {}
      }

      const regions = getWorldRegions(worldPath, 'overworld');
      const stats = parsePlayerStats(worldPath);
      const advancements = parseAdvancements(worldPath);
      const sizeBytes = getDirSize(worldPath);
      const lastPlayed = nbtData?.lastPlayed || fs.statSync(levelDatPath).mtime.toISOString();

      worlds.push({
        folderName:    entry,
        displayName:   nbtData?.worldName  || entry,
        gameMode:      nbtData?.gameMode   || 'Survival',
        difficulty:    nbtData?.difficulty || 'Normal',
        hardcore:      nbtData?.hardcore   || false,
        cheats:        nbtData?.cheats     || false,
        mcDay:         nbtData?.mcDay      ?? null,
        seed:          nbtData?.seed       || null,
        mcVersion:     nbtData?.version    || null,
        spawnX:        nbtData?.spawnX     || 0,
        spawnY:        nbtData?.spawnY     || 64,
        spawnZ:        nbtData?.spawnZ     || 0,
        sizeBytes, sizeFormatted: formatBytes(sizeBytes),
        lastPlayed, iconBase64,
        hasNether: fs.existsSync(path.join(worldPath, 'DIM-1')),
        hasEnd:    fs.existsSync(path.join(worldPath, 'DIM1')),
        regionCount: regions.length,
        regionCoords: regions.map(r => ({ rx: r.rx, rz: r.rz })).slice(0, 500),
        stats, advancements, worldPath,
      });
    } catch (e) { console.error('World error', entry, e.message); }
  }

  worlds.sort((a,b) => new Date(b.lastPlayed) - new Date(a.lastPlayed));
  res.json({ worlds, savesDir, count: worlds.length });
});

// World regions — real biomes + structures
// Streams back region data as NDJSON so the client can render progressively
app.get('/api/world-regions', async (req, res) => {
  const { worldPath, dimension = 'overworld' } = req.query;
  if (!worldPath) return res.status(400).json({ error: 'worldPath required' });

  const regions = getWorldRegions(worldPath, dimension);
  if (!regions.length) return res.json({ regions: [], structures: [], count: 0 });

  // For large worlds parsing every chunk is slow — use streaming JSON
  // Send headers immediately, then stream each region as it's parsed
  res.setHeader('Content-Type', 'application/json');

  const allStructures = [];
  const allRegions    = [];

  for (const r of regions) {
    try {
      const { chunks, structures } = await readRegionFull(r.file, r.rx, r.rz);
      allRegions.push({ rx: r.rx, rz: r.rz, chunks });
      allStructures.push(...structures);
    } catch (e) {
      console.error('Region parse error', r.file, e.message);
      allRegions.push({ rx: r.rx, rz: r.rz, chunks: [] });
    }
  }

  // Deduplicate structures by type + approximate position
  const seen = new Set();
  const uniqueStructures = allStructures.filter(s => {
    const key = `${s.type}:${Math.round(s.x/32)}:${Math.round(s.z/32)}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });

  res.json({ regions: allRegions, structures: uniqueStructures, count: regions.length });
});

// Fast endpoint — just chunk presence (no biome/structure), for quick initial load
app.get('/api/world-regions-fast', (req, res) => {
  const { worldPath, dimension = 'overworld' } = req.query;
  if (!worldPath) return res.status(400).json({ error: 'worldPath required' });
  const regions = getWorldRegions(worldPath, dimension);
  const regionData = regions.map(r => {
    try {
      const buf = fs.readFileSync(r.file);
      if (buf.length < 8192) return { rx: r.rx, rz: r.rz, chunks: [] };
      const chunks = [];
      for (let i = 0; i < 1024; i++) {
        const offset = ((buf[i*4] << 16) | (buf[i*4+1] << 8) | buf[i*4+2]) * 4096;
        if (offset < 8192 || buf[i*4+3] === 0) continue;
        chunks.push({ cx: i % 32, cz: Math.floor(i / 32) });
      }
      return { rx: r.rx, rz: r.rz, chunks };
    } catch { return { rx: r.rx, rz: r.rz, chunks: [] }; }
  });
  res.json({ regions: regionData, count: regions.length });
});

app.get('/api/mods', (req, res) => {
  const { gameDir } = req.query;
  const modsDir = path.join(gameDir || MC_DIR, 'mods');
  if (!fs.existsSync(modsDir)) return res.json({ mods: [], modsDir, error: 'No mods folder at ' + modsDir });

  const files = safeReadDir(modsDir).filter(f => f.endsWith('.jar') || f.endsWith('.jar.disabled'));
  const mods = files.map(file => {
    const filePath = path.join(modsDir, file);
    const enabled  = !file.endsWith('.disabled');
    const cleanName = file.replace(/\.jar(\.disabled)?$/, '');
    const stat = fs.statSync(filePath);

    let name = cleanName, version = null, mcVersion = null;
    // Name-MCVer-ModVer pattern
    let m = cleanName.match(/^(.+?)-(\d+\.\d+(?:\.\d+)?)-(\d+[\d.].*)$/);
    if (m) { name = m[1]; mcVersion = m[2]; version = m[3]; }
    else {
      // Name-mc1.x.x-ver
      m = cleanName.match(/^(.+?)-mc(\d+\.\d+(?:\.\d+)?)-(.+)$/i);
      if (m) { name = m[1]; mcVersion = m[2]; version = m[3]; }
      else {
        // Name-ver
        m = cleanName.match(/^(.+?)-(\d+[\d.].*)$/);
        if (m) { name = m[1]; version = m[2]; }
      }
    }
    const displayName = name.replace(/[-_]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()).trim();

    return {
      fileName: file, displayName, rawName: cleanName,
      version: version || null, mcVersion: mcVersion || null,
      enabled, sizeBytes: stat.size, sizeFormatted: formatBytes(stat.size),
      modified: stat.mtime, filePath,
    };
  }).sort((a,b) => a.displayName.localeCompare(b.displayName));

  res.json({ mods, modsDir, count: mods.length, enabled: mods.filter(m=>m.enabled).length });
});

app.post('/api/mods/toggle', (req, res) => {
  const { filePath, enabled } = req.body;
  if (!filePath) return res.status(400).json({ error: 'filePath required' });
  try {
    const newPath = enabled ? filePath + '.disabled' : filePath.replace(/\.jar\.disabled$/, '.jar');
    fs.renameSync(filePath, newPath);
    res.json({ ok: true, newPath, enabled: !enabled });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ─── Modrinth API ─────────────────────────────────────────────────────────────
const MR_HEADERS = { 'User-Agent': 'CraftControl/2.0 (local-minecraft-dashboard)' };
const MR_BASE    = 'https://api.modrinth.com/v2';

function mapHit(h) {
  return {
    id: h.project_id, slug: h.slug, title: h.title,
    description: h.description, author: h.author,
    downloads: h.downloads, follows: h.follows,
    icon: h.icon_url, color: h.color,
    categories: h.categories || [],
    displayCategories: h.display_categories || [],
    versions: h.versions || [],
    latestVersion: h.latest_version,
    clientSide: h.client_side, serverSide: h.server_side,
    dateCreated: h.date_created, dateModified: h.date_modified,
    license: h.license,
    gallery: h.gallery || [],
    url: `https://modrinth.com/mod/${h.slug}`,
  };
}

// Search with full filter support
app.get('/api/modrinth/search', async (req, res) => {
  const { q = '', version, loader, category, sort = 'relevance', limit = 20, offset = 0 } = req.query;
  try {
    const facets = [['project_type:mod']];
    if (version)  facets.push([`versions:${version}`]);
    if (loader)   facets.push([`categories:${loader.toLowerCase()}`]);
    if (category) facets.push([`categories:${category}`]);

    const params = new URLSearchParams({
      query: q, limit, offset,
      index: sort,
      facets: JSON.stringify(facets),
    });
    const r    = await fetch(`${MR_BASE}/search?${params}`, { headers: MR_HEADERS });
    const data = await r.json();
    res.json({ hits: (data.hits || []).map(mapHit), total: data.total_hits || 0, offset: data.offset || 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Featured / popular (no query)
app.get('/api/modrinth/featured', async (req, res) => {
  const { version, loader, sort = 'downloads', limit = 20, offset = 0 } = req.query;
  try {
    const facets = [['project_type:mod']];
    if (version) facets.push([`versions:${version}`]);
    if (loader)  facets.push([`categories:${loader.toLowerCase()}`]);
    const params = new URLSearchParams({ query: '', limit, offset, index: sort, facets: JSON.stringify(facets) });
    const r    = await fetch(`${MR_BASE}/search?${params}`, { headers: MR_HEADERS });
    const data = await r.json();
    res.json({ hits: (data.hits || []).map(mapHit), total: data.total_hits || 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Full project details (description body, gallery, links)
app.get('/api/modrinth/project/:id', async (req, res) => {
  try {
    const [projRes, membersRes] = await Promise.all([
      fetch(`${MR_BASE}/project/${req.params.id}`, { headers: MR_HEADERS }),
      fetch(`${MR_BASE}/project/${req.params.id}/members`, { headers: MR_HEADERS }),
    ]);
    const proj    = await projRes.json();
    const members = await membersRes.json().catch(() => []);
    res.json({ ...proj, members: Array.isArray(members) ? members : [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Versions list filtered by game version + loader
app.get('/api/modrinth/versions', async (req, res) => {
  const { projectId, gameVersion, loader } = req.query;
  if (!projectId) return res.status(400).json({ error: 'projectId required' });
  try {
    const params = [];
    if (gameVersion) params.push(`game_versions=["${gameVersion}"]`);
    if (loader)      params.push(`loaders=["${loader.toLowerCase()}"]`);
    const url = `${MR_BASE}/project/${projectId}/version${params.length ? '?' + params.join('&') : ''}`;
    const r   = await fetch(url, { headers: MR_HEADERS });
    const data = await r.json();
    res.json({ versions: Array.isArray(data) ? data : [] });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Resolve dependencies for a version
app.get('/api/modrinth/dependencies', async (req, res) => {
  const { versionId } = req.query;
  if (!versionId) return res.status(400).json({ error: 'versionId required' });
  try {
    const r = await fetch(`${MR_BASE}/version/${versionId}`, { headers: MR_HEADERS });
    const v = await r.json();
    const deps = v.dependencies || [];
    // Fetch names for each required dependency
    const resolved = await Promise.all(deps.map(async d => {
      if (!d.project_id) return { ...d, title: d.file_name || 'Unknown' };
      try {
        const pr = await fetch(`${MR_BASE}/project/${d.project_id}`, { headers: MR_HEADERS });
        const p  = await pr.json();
        return { ...d, title: p.title, slug: p.slug, icon: p.icon_url };
      } catch { return { ...d, title: d.project_id }; }
    }));
    res.json({ dependencies: resolved });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Download + install a mod version into the mods folder
app.post('/api/modrinth/download', async (req, res) => {
  const { versionId, gameDir } = req.body;
  if (!versionId || !gameDir) return res.status(400).json({ error: 'versionId and gameDir required' });
  const modsDir = path.join(gameDir, 'mods');
  if (!fs.existsSync(modsDir)) {
    try { fs.mkdirSync(modsDir, { recursive: true }); }
    catch (e) { return res.status(500).json({ error: 'Cannot create mods folder: ' + e.message }); }
  }
  try {
    const vr    = await fetch(`${MR_BASE}/version/${versionId}`, { headers: MR_HEADERS });
    const vdata = await vr.json();
    const file  = vdata.files?.find(f => f.primary) || vdata.files?.[0];
    if (!file) return res.status(404).json({ error: 'No downloadable file found for this version' });
    // Check if already installed
    const destPath = path.join(modsDir, file.filename);
    if (fs.existsSync(destPath)) return res.json({ ok: true, filename: file.filename, alreadyInstalled: true, size: formatBytes(file.size) });
    const dl = await fetch(file.url);
    if (!dl.ok) return res.status(500).json({ error: `Download failed: HTTP ${dl.status}` });
    fs.writeFileSync(destPath, Buffer.from(await dl.arrayBuffer()));
    res.json({ ok: true, filename: file.filename, size: formatBytes(file.size), alreadyInstalled: false });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Check which mods from a list are already installed (by slug/filename match)
app.post('/api/modrinth/check-installed', (req, res) => {
  const { gameDir, slugs } = req.body;
  if (!gameDir || !slugs) return res.status(400).json({ error: 'gameDir and slugs required' });
  const modsDir = path.join(gameDir, 'mods');
  const files   = fs.existsSync(modsDir) ? safeReadDir(modsDir).map(f => f.toLowerCase()) : [];
  const result  = {};
  for (const slug of slugs) {
    result[slug] = files.some(f => f.includes(slug.toLowerCase().replace(/-/g,'').slice(0,12)));
  }
  res.json({ installed: result });
});

app.get('/api/options', (req, res) => {
  const { gameDir } = req.query;
  const dir = (gameDir && gameDir.trim()) ? gameDir : MC_DIR;
  const optPath = path.join(dir, 'options.txt');
  if (!fs.existsSync(optPath)) return res.json({ options:{}, error:'options.txt not found at '+optPath, optPath });
  try {
    const options = {};
    for (const line of fs.readFileSync(optPath,'utf8').split(/\r?\n/)) {
      const idx = line.indexOf(':');
      if (idx !== -1) options[line.slice(0,idx).trim()] = line.slice(idx+1).trim();
    }
    res.json({ options, optPath });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/options', (req, res) => {
  const { gameDir, options } = req.body;
  const dir = (gameDir && gameDir.trim()) ? gameDir : MC_DIR;
  const optPath = path.join(dir, 'options.txt');
  if (!fs.existsSync(optPath)) return res.status(404).json({ error: 'options.txt not found at ' + optPath });
  try {
    const lines = fs.readFileSync(optPath,'utf8').split(/\r?\n/);
    const seen = new Set();
    const updated = lines.map(line => {
      const idx = line.indexOf(':');
      if (idx === -1) return line;
      const key = line.slice(0,idx).trim();
      if (key in options) { seen.add(key); return `${key}:${options[key]}`; }
      return line;
    });
    for (const [k,v] of Object.entries(options)) if (!seen.has(k)) updated.push(`${k}:${v}`);
    fs.writeFileSync(optPath, updated.join('\r\n'), 'utf8');
    res.json({ ok: true, updated: seen.size });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/worlds/backup', (req, res) => {
  const { worldPath, worldName } = req.body;
  if (!worldPath || !fs.existsSync(worldPath)) return res.status(400).json({ error: 'worldPath required and must exist' });
  const backupsDir = path.join(MC_DIR, 'craftcontrol-backups');
  if (!fs.existsSync(backupsDir)) fs.mkdirSync(backupsDir, { recursive: true });
  const ts   = new Date().toISOString().replace(/[:.]/g,'-').slice(0,19);
  const dest = path.join(backupsDir, `${worldName||path.basename(worldPath)}_${ts}`);
  try {
    copyDirSync(worldPath, dest);
    res.json({ ok: true, backupName: path.basename(dest), destDir: dest, sizeFormatted: formatBytes(getDirSize(dest)) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/worlds/backups', (req, res) => {
  const backupsDir = path.join(MC_DIR, 'craftcontrol-backups');
  if (!fs.existsSync(backupsDir)) return res.json({ backups: [] });
  const backups = safeReadDir(backupsDir).map(entry => {
    const full = path.join(backupsDir, entry);
    try {
      const stat = fs.statSync(full);
      if (!stat.isDirectory()) return null;
      return { name: entry, path: full, created: stat.birthtime||stat.ctime, sizeFormatted: formatBytes(getDirSize(full)) };
    } catch { return null; }
  }).filter(Boolean).sort((a,b) => new Date(b.created)-new Date(a.created));
  res.json({ backups });
});

app.post('/api/worlds/restore', (req, res) => {
  const { backupPath, targetWorldPath } = req.body;
  if (!backupPath || !fs.existsSync(backupPath)) return res.status(400).json({ error: 'backupPath must exist' });
  if (!targetWorldPath) return res.status(400).json({ error: 'targetWorldPath required' });
  try {
    if (fs.existsSync(targetWorldPath)) {
      copyDirSync(targetWorldPath, targetWorldPath + '_pre-restore_' + Date.now());
      fs.rmSync(targetWorldPath, { recursive: true, force: true });
    }
    copyDirSync(backupPath, targetWorldPath);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/resourcepacks', (req, res) => {
  const rpDir = path.join(MC_DIR, 'resourcepacks');
  if (!fs.existsSync(rpDir)) return res.json({ packs: [], rpDir });
  const packs = safeReadDir(rpDir).map(f => {
    try {
      const stat = fs.statSync(path.join(rpDir, f));
      return { name: f, isDir: stat.isDirectory(), sizeFormatted: formatBytes(stat.size), modified: stat.mtime };
    } catch { return null; }
  }).filter(Boolean);
  res.json({ packs, rpDir });
});

app.get('/api/screenshots', (req, res) => {
  const ssDir = path.join(MC_DIR, 'screenshots');
  if (!fs.existsSync(ssDir)) return res.json({ shots: [], ssDir, count: 0 });
  const shots = safeReadDir(ssDir)
    .filter(f => /\.(png|jpg|jpeg)$/i.test(f))
    .map(f => {
      try { const s = fs.statSync(path.join(ssDir, f)); return { name: f, sizeFormatted: formatBytes(s.size), taken: s.mtime }; }
      catch { return null; }
    }).filter(Boolean)
    .sort((a,b) => new Date(b.taken)-new Date(a.taken)).slice(0,50);
  res.json({ shots, ssDir, count: shots.length });
});

// Landing page at root
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'landing.html')));
// Dashboard at /dashboard or /app
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/app', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
// Fallback
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => {
  console.log(`\n CraftControl v2  →  http://localhost:${PORT}`);
  console.log(` Minecraft dir:      ${MC_DIR}`);
  console.log(` Found:              ${fs.existsSync(MC_DIR)}\n`);
});
