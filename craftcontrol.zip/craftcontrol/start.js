#!/usr/bin/env node
/**
 * CraftControl startup — run this directly with:
 *   node start.js
 * It will auto-open your browser.
 */
const { execSync, spawn } = require('child_process');
const path = require('path');

console.log('🟢 Starting CraftControl…');

// Start server
const server = spawn('node', [path.join(__dirname, 'server.js')], {
  stdio: 'inherit',
  cwd: __dirname,
});

// Wait a moment then open browser
setTimeout(() => {
  const url = 'http://localhost:3000';
  const platform = process.platform;
  try {
    if (platform === 'darwin') execSync(`open "${url}"`);
    else if (platform === 'win32') execSync(`start "${url}"`);
    else execSync(`xdg-open "${url}"`);
    console.log(`\n🌐 Opened ${url} in your browser`);
  } catch {
    console.log(`\n🌐 Open this in your browser: ${url}`);
  }
}, 800);

process.on('SIGINT', () => { server.kill(); process.exit(); });
